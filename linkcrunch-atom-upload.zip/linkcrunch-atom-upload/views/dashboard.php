
<?php

$current_user 		=  wp_get_current_user();
// see if the array is valid for avatar, then build markup
if ( is_array( $user_icon_src ) ) {
	$user_icon 	= '<img src="'. $user_icon_src[0].'" alt="avatar" class="user-icon" />';
}

      // user info
      global $current_user;
      wp_get_current_user();
      $user_icon_src 	= wp_get_attachment_image_src( get_user_meta( get_current_user_id(), 'user_icon_id', true ), array( 150, 150 ) );
      $user_icon 		= '';
      $username = $current_user->user_login;
      $themecolor     = get_user_meta ( $current_user->ID, 'custom_settings_theme', true );
      $personalname   = get_user_meta ( $current_user->ID, 'custom_settings_personalname', true );
      $tagline 	= get_user_meta( $current_user->ID, 'custom_settings_tagline', true );
      $registered = date_i18n( "F, Y", strtotime( get_the_author_meta( 'user_registered', $current_user->ID) ) );
      $location  = get_user_meta( $current_user->ID, 'custom_settings_location', true);
      $user_icon_src 	= wp_get_attachment_image_src( get_user_meta( $current_user->ID, 'user_icon_id', true ), array( 150, 150 ) );
      $user_icon 		= '';

      // FB user pic if signed in w/ FB

      if ( $fb_id = get_user_meta( $current_user->ID, '_fb_user_id', true ) ) {

      				$fb_url = 'https://graph.facebook.com/' . $fb_id . '/picture?width=400&height=400';
      				$avatar = "<img style='border-radius: 50%;' src='{$fb_url}'  />";

      }

?>

<div class="well" id="dashwell" >
    <div id="flexy" >
    	<div class="left" >
    	 <h3 class="username">

            <!-- username or personalname -->
        	 <? if (empty($personalname)) : ?>
        	 <? echo ucfirst("$user_name"); ?>
        	 <? else : ?>
        	 <? echo $personalname; ?>
        	 <? endif; ?>

					 
    	 </h3>

    	 <? if (empty($tagline)) : ?>
    	   <p class="location" ><? echo $location; ?></p>
    	   <p class="joindate">Joined <? echo $registered; ?></p>
    	 <? else : ?>
      	 <p class="location" ><? echo $location; ?></p>
      	 <p class="joindate"><? echo $tagline; ?></p>
    	 <? endif; ?>

    	</div>

    	<div class="right" >
    	      <? if (!empty($user_icon)) : ?>

    	      	<? echo $user_icon; ?>


    	      <? elseif (!empty($avatar)) : ?>

    	      	<? echo $avatar; ?>

    	      <? else : ?>
    	      	<div class="emptyavatar"></div>
    	      <? endif; ?>

    	</div>
    </div>

</div>

<div  class="allbuttons">


  <button onclick="window.location.href='/add'"  class="emailbutton">
  <div><span class="glyphicon glyphicon-plus"></span></div>
  Add a link</button>

  <button onclick="window.location.href='/view'" style="background: #36a9ae;" class="emailbutton">
  <div><span class="glyphicon glyphicon-pencil"></span></div>
  Edit links</button>

  <button onclick="window.location.href='/dashboard/stats'" style="background: #36a9ae;" class="emailbutton">
  <div><span class="glyphicon glyphicon-heart-empty"></span></div>
  Insights</button>

  <button onclick="window.location.href='/dashboard/settings'" style="background: #36a9ae;" class="emailbutton">
  <div><span class="glyphicon glyphicon-cog"></span></div>
  Settings</button>



</div>
