
<?php
// include SQL query files

include('views-clicks.php');
include('referrer.php');


?>

<div class="bigwrap">

	<div class="statswrap">
	  <div  class="card-row">

	    <h1 ><? echo $totalviews; ?></h1>
	    <h4>Page views</h4>

	  </div>
	  <div class="hardstats">
	  <div class="card-row">
	      <div class="card-half">
	          <h3><? echo $uniqueclickcount; ?></h3>
	          <p>Unique clicks</p>
	      </div>
	      <div class="card-half">
	          <h3><? echo $recurringclickcount; ?></h3>
	          <p>Returning clicks</p>
	      </div>
	</div>
	<div class="card-row">
	      <div class="card-half">
	          <h3><? echo $clicksperuser; ?></h3>
	          <p>Clicks per user</p>
	      </div>
	      <div class="card-half" >
	          <h3><? echo $bouncerate; ?></h3>
	          <p>Bounce rate</p>
	      </div>
	</div>
	</div>

	  <?php
			// run loop of user's buttons for which to show clicks on each in html
			if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post();


			    $theid = get_the_ID();
			    $button_name = get_post_meta(get_the_ID(), 'button_name',  true);
			    $count = get_post_meta(get_the_ID(), '_out_count', true);
			    if (!$count) {
			    	$count = '0';
			    }

	    ?>
	    <div class="buttonstats">


	    <div class="card-row">
	        <div class="card-half">
	            <? echo $button_name; ?>
	        </div>
	        <div class="card-half">
	          <p class="bold"><? echo $count; ?>
	          <p>Clicks</p>
	        </div>
		  </div>



	    <?  endwhile; endif; ?>
	   </div>
	   <hr>
	   <h3>Top traffic sources</h3>
	   <div class="socialrefers">

				<div class="single">
				<? echo $tml; ?>
					<div><? echo $website ?></div>
					<div><strong><? echo $webcount; ?></strong></div>
				</div>


			<? endforeach; ?>
			<? if (!$referquery) : ?>
			<i>No data yet.</i>
			<? endif; ?>
		</div>
		<h3 style="text-align:center;">Top countries</h3>
		<?php include('countries.php'); ?>



	<?
	include_once('graphs.php');
	?>
</div>
