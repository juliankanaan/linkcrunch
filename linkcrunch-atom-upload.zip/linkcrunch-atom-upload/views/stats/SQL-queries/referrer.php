<?php

global $wpdb;
	 $current_user = wp_get_current_user();
	 $id = $current_user->ID;

   // based on user input, build SQl query

	 if ($_GET['month']) {
	    $frame = 'and view_time between DATE_ADD(NOW(), INTERVAL -1 MONTH) and NOW()';
	 }
	 elseif ($_GET['lifetime']) {
	    $frame = '';
	 } else {
	    $frame = 'and view_time between DATE_ADD(NOW(), INTERVAL -7 DAY) and NOW()';
	 }

   // do the SQL query
	 $referquery = $wpdb->get_results(
		 	"
			SELECT referringurl, count(referringurl) AS referrers
			FROM wp_viewlog
			WHERE authorid = '" . $id . "'
			'" . $frame . "'
			GROUP BY referringurl
			ORDER BY referrers DESC LIMIT 3

			;

			"
		);

    // begin loop to match referring sites to their icons (if available). build the markup
		foreach ($referquery as $refer) : ?>

		<?
		$website  = $refer->referringurl;
		$webcount = $refer->referrers;
		if (strpos($website, 'facebook') !== false) {
			$website = 'Facebook';
			$tml     = '<i style="background: #3d5a98;" class="fa fa-facebook icon"></i>';
		} elseif (strpos($website, 't.co') !== false) {
			$website = 'Twitter';
			$tml     = '<i style="background: #62caec;" class="fa fa-twitter icon"></i>';

		} elseif (strpos($website, 'instagram') !== false) {
			$website = 'Instagram';
			$tml     = '<i style="background: linear-gradient(to right top, rgba(255, 82, 99, 0.9) 10%, rgba(255, 115, 129, 0.9) 65%, rgba(252, 189, 1, 0.9) 125%);" class="fa fa-instagram icon"></i>';

		} else {
			$tml = '<i style="background: darkgrey;" class="fa fa-link icon"></i>';
		}


?>
