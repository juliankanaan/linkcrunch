<?php


global $wpdb;
	 $current_user = wp_get_current_user();
	 $id = $current_user->ID;

   // build SQL query for wp_viewlog table
	$countryqueries = $wpdb->get_results(
		 	"
			SELECT view_country, count(view_country) AS countries
			FROM wp_viewlog
			WHERE authorid = '" . $id . "'
			AND view_country is not null


			GROUP BY view_country
			ORDER BY countries DESC LIMIT 3

			;

			"
		);


    // loop over results
		foreach ($countryqueries as $countryquery) : ?>

		<?
		$country  = $countryquery->countries;
		$countrycount = $countryquery->view_country;
    // add exceptions (ie. no data or no count yet)
		if (!$country ) {
		    $country = 'unknown';
		}
		if (!$countrycount ) {
		    $countrycount = '';
		}

    // loop markup with each country returned in SQL query
		?>
			<div class="single">

				<div><? echo $country; ?></div>
				<p><strong><? echo $countrycount; ?></strong></p>
			</div>


		<? endforeach; ?>
		<? if (!$countryqueries) : ?>
		  <i>No data yet.</i>
		<? endif; ?>
