<?php

global $wpdb;
// url params
if ($_GET['month']) {
$id = $current_user->ID;

 global $wpdb;
  //month data

      $totalviews = $wpdb->get_results(
        "
        SELECT * FROM wp_viewlog WHERE authorid = '" . $id . "'
                   and view_time between DATE_ADD(NOW(), INTERVAL -1 MONTH) and NOW()
              "
      );
      $totalviews = $wpdb->num_rows;



      $nonuniqueusers = $wpdb->get_results(
      	"
      	SELECT *, COUNT(click_ip) FROM wp_clicklog WHERE authorid = '" . $id . "' GROUP BY click_ip HAVING ( COUNT(click_ip) > 1 ) and click_time between DATE_ADD(NOW(), INTERVAL -1 MONTH) AND NOW()

      	"
      );

      $uniqueclickcount = $wpdb->num_rows;

	    $totalclickdata = $wpdb->get_results(
      	"
      	SELECT * FROM wp_clicklog WHERE authorid = '" . $id . "' and click_time between DATE_ADD(NOW(), INTERVAL -1 MONTH) AND NOW()

      	"
      );

      $totalclickcount = $wpdb->num_rows;


} elseif ($_GET['lifetime']) {
$id = $current_user->ID;
$frame = '';
  //lifetime data

        global $wpdb;

        $viewdata = $wpdb->get_results(
        	"
        	SELECT * FROM wp_viewlog WHERE authorid = '" . $id . "'

        	"
        );
        $totalviews = $wpdb->num_rows;

        $nonuniqueusers = $wpdb->get_results(
        	"
        	SELECT *, COUNT(click_ip) FROM wp_clicklog WHERE authorid = '" . $id . "' GROUP BY click_ip HAVING ( COUNT(click_ip) > 1 )

        	"
        );

        $uniqueclickcount = $wpdb->num_rows;

        $totalclickdata = $wpdb->get_results(
        	"
        	SELECT * FROM wp_clicklog WHERE authorid = '" . $id . "'

        	"
        );

        $totalclickcount = $wpdb->num_rows;
} else {

$id = $current_user->ID;

 global $wpdb;
  //month data

      $totalviews = $wpdb->get_results(
        "
        SELECT * FROM wp_viewlog WHERE authorid = '" . $id . "'
                   and view_time between DATE_ADD(NOW(), INTERVAL -7 DAY) and NOW()
              "
      );
      $totalviews = $wpdb->num_rows;



      $nonuniqueusers = $wpdb->get_results(
      	"
      	SELECT *, COUNT(click_ip) FROM wp_clicklog WHERE authorid = '" . $id . "' GROUP BY click_ip HAVING ( COUNT(click_ip) > 1 ) and click_time between DATE_ADD(NOW(), INTERVAL -7 DAY) AND NOW()

      	"
      );

      $uniqueclickcount = $wpdb->num_rows;

	$totalclickdata = $wpdb->get_results(
      	"
      	SELECT * FROM wp_clicklog WHERE authorid = '" . $id . "' and click_time between DATE_ADD(NOW(), INTERVAL -7 DAY) AND NOW()

      	"
      );



      $totalclickcount = $wpdb->num_rows;



}


// math
$recurringclickcount = $totalclickcount - $uniqueclickcount;
if ($totalviews >= 1){
  $bouncerate          = round((1 - ($totalclickcount / $totalviews) )*100  ) . '%';
} else {
  $bouncerate          = 'N/A';
}
if ($uniqueclickcount >= 1){
  $clicksperuser       = round(($recurringclickcount / $totalclickcount), 2);
} else {
$clicksperuser = 'N/A';
  $uniqueclickcount = '0';
}


?>
