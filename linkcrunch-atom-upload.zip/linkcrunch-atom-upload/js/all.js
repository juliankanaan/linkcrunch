


jQuery(document).ready(function($) {

$("#clap").click(function() {
  $.ajax({
        url: example_ajax_obj.ajaxurl,
        data: {
            'action': 'clap',
            'value' : 1
        },
        success:function(data) {
            // This outputs the result of the ajax request
            console.log(data);



        },
        error: function(errorThrown){
            console.log(errorThrown);
            alert("Fail!");
        }
    });
}); // end clap function


$("#wave").click(function() {
  $.ajax({
        url: example_ajax_obj.ajaxurl,
        data: {
            'action': 'wave',
            'value' : 1
        },
        success:function(data) {
            // This outputs the result of the ajax request
            console.log(data);
            // alert("Success!");
        },
        error: function(errorThrown){
            console.log(errorThrown);
            alert("Fail!");
        }
    });
}); // end wave function


});
