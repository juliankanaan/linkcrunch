<?php


function complete_info( $user_id ) {

  if ( empty( $user_id )) {

    global $current_user;
    wp_get_current_user();
    $user_id = $current_user->ID;

  }

  $complete = array (
    'username' => '',
    'personalname' => '',
    'location' => '',
    'username' => '',
  );


return $complete;


}



?>
